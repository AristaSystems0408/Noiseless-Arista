/*
 * Noiseless — content script (isolated world).
 *
 * Detects a meeting when the page starts using the microphone, asks the user whether to
 * start noise cancellation, shows a small floating control, and relays commands between
 * the popup and the page hook (inject.js).
 */
(() => {
  const TAG = '__noiseless';
  const host = location.hostname;

  const PLATFORMS = [
    [/(^|\.)meet\.google\.com$/, 'Google Meet'],
    [/(^|\.)teams\.(microsoft\.com|live\.com|cloud\.microsoft)$/, 'Microsoft Teams'],
    [/(^|\.)zoom\.us$/, 'Zoom'],
    [/(^|\.)webex\.com$/, 'Webex'],
  ];
  const platform = (PLATFORMS.find(([re]) => re.test(host)) || [null, host])[1];

  const state = {
    detected: false,
    active: false,
    decided: false, // user answered the prompt on this page
    strength: 95,
    autoStart: false,
    profiles: {},
    label: '',
    levels: null,
    calibration: null,
    error: null,
    uiHidden: false,
    engine: null,
    audioState: null,
  };

  const toPage = (msg) => window.postMessage({ [TAG]: 'content', ...msg }, '*');

  function sendConfig() {
    toPage({
      type: 'config',
      workletBase: chrome.runtime.getURL('worklet/'),
      strength: state.strength,
      profiles: state.profiles,
    });
  }

  function report() {
    chrome.runtime
      .sendMessage({ type: 'tab-state', detected: state.detected, active: state.active })
      .catch(() => {});
  }

  function setActive(active) {
    state.active = active;
    state.decided = true;
    toPage({ type: 'set-active', active });
    ui.render();
    report();
  }

  function setAutoStart(enabled) {
    chrome.storage.sync.get({ autoStartSites: {} }).then(({ autoStartSites }) => {
      if (enabled) autoStartSites[host] = true;
      else delete autoStartSites[host];
      chrome.storage.sync.set({ autoStartSites });
    });
  }

  function startCalibration() {
    if (!state.detected || isCalibrating()) return;
    state.calibration = { phase: 'starting', startedAt: Date.now(), durationMs: 0 };
    state.uiHidden = false;
    toPage({ type: 'calibrate' });
    ui.render();
  }

  const isCalibrating = () =>
    !!state.calibration && ['starting', 'noise', 'voice'].includes(state.calibration.phase);

  let calibrationTimer;
  function onCalibration(msg) {
    clearTimeout(calibrationTimer);
    state.calibration = {
      phase: msg.phase,
      startedAt: Date.now(),
      durationMs: msg.durationMs || 0,
      message: msg.message || '',
      separationDb: msg.profile ? msg.profile.separationDb : null,
    };
    if (msg.phase === 'done' && msg.profile) {
      state.profiles[msg.label] = msg.profile;
      chrome.storage.local.get({ profiles: {} }).then(({ profiles }) => {
        profiles[msg.label] = msg.profile;
        chrome.storage.local.set({ profiles });
      });
    }
    if (msg.phase === 'done' || msg.phase === 'error') {
      calibrationTimer = setTimeout(() => {
        state.calibration = null;
        ui.render();
      }, 5000);
    }
    ui.render();
  }

  // ── Page hook → here ────────────────────────────────────────────
  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data[TAG] !== 'page') return;
    const msg = e.data;
    switch (msg.type) {
      case 'hello':
        if (loaded) sendConfig();
        break;
      case 'capture-started':
        state.detected = true;
        state.label = msg.label || '';
        state.error = null;
        state.uiHidden = false;
        if (!state.decided && state.autoStart) setActive(true);
        ui.render();
        report();
        break;
      case 'capture-changed':
        state.label = msg.label || state.label;
        ui.render();
        break;
      case 'capture-ended':
        state.detected = false;
        state.levels = null;
        state.calibration = null;
        ui.render();
        report();
        break;
      case 'levels':
        state.levels = { inRms: msg.inRms, outRms: msg.outRms, voice: msg.voice };
        ui.updateLevels();
        break;
      case 'calibration':
        onCalibration(msg);
        break;
      case 'engine':
        state.engine = msg.engine;
        break;
      case 'audio-state':
        state.audioState = msg.state;
        ui.updateLevels();
        break;
      case 'error':
        state.error = msg.message;
        state.uiHidden = false;
        ui.render();
        break;
    }
  });

  // ── Popup → here ────────────────────────────────────────────────
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    switch (msg && msg.type) {
      case 'get-state': {
        const profile = state.profiles[state.label];
        sendResponse({
          platform,
          host,
          detected: state.detected,
          active: state.active,
          autoStart: state.autoStart,
          label: state.label,
          levels: state.levels,
          calibration: state.calibration,
          profile: profile ? { separationDb: profile.separationDb, createdAt: profile.createdAt } : null,
          error: state.error,
          uiHidden: state.uiHidden,
          engine: state.engine,
          audioState: state.audioState,
        });
        break;
      }
      case 'set-active':
        if (state.detected) setActive(!!msg.active);
        sendResponse({ ok: state.detected });
        break;
      case 'calibrate':
        startCalibration();
        sendResponse({ ok: state.detected });
        break;
      case 'show-controls':
        state.uiHidden = false;
        ui.render();
        sendResponse({ ok: true });
        break;
      default:
        return false;
    }
    return false;
  });

  // ── Settings ────────────────────────────────────────────────────
  let loaded = false;
  Promise.all([
    chrome.storage.sync.get({ strength: 95, autoStartSites: {} }),
    chrome.storage.local.get({ profiles: {} }),
  ]).then(([sync, local]) => {
    state.strength = sync.strength;
    state.autoStart = !!sync.autoStartSites[host];
    state.profiles = local.profiles;
    loaded = true;
    sendConfig();
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync' && changes.strength) {
      state.strength = changes.strength.newValue;
      toPage({ type: 'set-strength', strength: state.strength });
    }
    if (area === 'sync' && changes.autoStartSites) {
      state.autoStart = !!(changes.autoStartSites.newValue || {})[host];
      ui.render();
    }
    if (area === 'local' && changes.profiles) {
      state.profiles = changes.profiles.newValue || {};
      sendConfig();
    }
  });

  // ── In-page UI ──────────────────────────────────────────────────
  const CSS = `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: "Segoe UI", system-ui, -apple-system, sans-serif; }
    .card {
      width: 300px; padding: 14px 16px; border-radius: 12px;
      background: #181D25; color: #E8ECF1; border: 1px solid #2A3240;
      box-shadow: 0 12px 32px rgba(0,0,0,.45); font-size: 13px; line-height: 1.4;
      animation: in .18s ease-out;
    }
    @keyframes in { from { opacity: 0; transform: translateY(6px); } }
    .head { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
    .brand { font-weight: 700; letter-spacing: .08em; font-size: 12px; flex: 1; }
    .mark {
      width: 22px; height: 22px; border-radius: 6px; background: #0B0E11;
      display: grid; grid-auto-flow: column; align-items: center; justify-content: center; gap: 2px;
    }
    .mark i { display: block; width: 2px; border-radius: 1px; background: #00D4AA; }
    .x {
      all: unset; cursor: pointer; color: #8893A2; width: 22px; height: 22px; border-radius: 6px;
      display: grid; place-items: center; font-size: 15px;
    }
    .x:hover { background: #242B36; color: #E8ECF1; }
    .title { font-size: 14px; font-weight: 600; margin: 0 0 2px; }
    .sub { color: #8893A2; margin: 0 0 12px; }
    .row { display: flex; gap: 8px; }
    button.btn {
      all: unset; cursor: pointer; text-align: center; border-radius: 8px; padding: 8px 12px;
      font-weight: 600; font-size: 13px; flex: 1;
    }
    .btn.primary { background: #00D4AA; color: #0B0E11; }
    .btn.primary:hover { background: #2BE0BC; }
    .btn.secondary { background: #242B36; color: #E8ECF1; }
    .btn.secondary:hover { background: #2A3240; }
    .btn.danger { background: #3A1F28; color: #FF8098; }
    .btn.danger:hover { background: #4A2532; }
    label.check { display: flex; gap: 8px; align-items: center; margin-top: 10px; color: #8893A2; font-size: 12px; cursor: pointer; }
    label.check input { accent-color: #00D4AA; margin: 0; }
    .pill {
      display: flex; align-items: center; gap: 8px; padding: 6px 6px 6px 12px; border-radius: 999px;
      background: #181D25; color: #E8ECF1; border: 1px solid #2A3240;
      box-shadow: 0 8px 24px rgba(0,0,0,.4); font-size: 12px; animation: in .18s ease-out;
    }
    .pill .label { font-weight: 600; white-space: nowrap; }
    .pill .state { color: #8893A2; white-space: nowrap; min-width: 76px; }
    .pill button.btn { flex: none; padding: 5px 10px; border-radius: 999px; font-size: 12px; }
    .pill .x { width: 24px; height: 24px; border-radius: 999px; }
    .dot { width: 9px; height: 9px; border-radius: 50%; background: #566070; flex: none; transition: background .12s, box-shadow .12s; }
    .dot.idle { background: #00A888; }
    .dot.voice { background: #00E676; box-shadow: 0 0 0 4px rgba(0,230,118,.18); }
    .bar { height: 6px; border-radius: 3px; background: #242B36; overflow: hidden; margin: 10px 0 4px; }
    .bar > div { height: 100%; width: 0; background: #FECA57; }
    .bar.voice > div { background: #00E676; }
    .step { color: #8893A2; font-size: 11px; text-transform: uppercase; letter-spacing: .08em; margin-bottom: 4px; }
    .big { font-size: 18px; font-weight: 700; margin: 0 0 2px; }
    .ok { color: #00E676; } .warn { color: #FF9F43; } .err { color: #FF8098; }
  `;

  const ui = (() => {
    let hostEl, panel, dot, stateText;

    function ensure() {
      if (hostEl && hostEl.isConnected) return;
      hostEl = document.createElement('noiseless-controls');
      hostEl.style.cssText =
        'all: initial; position: fixed; left: 16px; bottom: 96px; z-index: 2147483647;';
      const root = hostEl.attachShadow({ mode: 'closed' });
      const style = document.createElement('style');
      style.textContent = CSS;
      panel = document.createElement('div');
      root.append(style, panel);
      (document.body || document.documentElement).append(hostEl);
    }

    function el(tag, className, text) {
      const node = document.createElement(tag);
      if (className) node.className = className;
      if (text != null) node.textContent = text;
      return node;
    }

    function button(text, kind, onClick) {
      const b = el('button', `btn ${kind}`, text);
      b.type = 'button';
      b.addEventListener('click', onClick);
      return b;
    }

    function closeButton(title, onClick) {
      const b = el('button', 'x', '×');
      b.type = 'button';
      b.title = title;
      b.setAttribute('aria-label', title);
      b.addEventListener('click', onClick);
      return b;
    }

    function mark() {
      const m = el('div', 'mark');
      [6, 12, 8].forEach((h) => {
        const i = el('i');
        i.style.height = `${h}px`;
        m.append(i);
      });
      return m;
    }

    function header(onClose) {
      const h = el('div', 'head');
      h.append(mark(), el('div', 'brand', 'NOISELESS'), closeButton('Hide', onClose));
      return h;
    }

    const hide = () => {
      state.uiHidden = true;
      render();
    };

    function promptView() {
      const card = el('div', 'card');
      card.append(
        header(() => {
          state.decided = true;
          render();
        }),
        el('p', 'title', `Meeting detected on ${platform}`),
        el('p', 'sub', 'Turn on noise cancellation to remove background noise from your microphone?')
      );
      const row = el('div', 'row');
      const check = el('input');
      check.type = 'checkbox';
      row.append(
        button('Start', 'primary', () => {
          if (check.checked) setAutoStart(true);
          setActive(true);
        }),
        button('Not now', 'secondary', () => {
          state.decided = true;
          render();
        })
      );
      const label = el('label', 'check');
      label.append(check, document.createTextNode(`Always start automatically on ${platform}`));
      card.append(row, label);
      return card;
    }

    function pillView() {
      const pill = el('div', 'pill');
      dot = el('span', 'dot');
      stateText = el('span', 'state');
      pill.append(
        dot,
        el('span', 'label', 'Noise cancellation'),
        stateText,
        state.active
          ? button('Stop', 'danger', () => setActive(false))
          : button('Start', 'primary', () => setActive(true)),
        closeButton('Hide (control stays in the toolbar icon)', hide)
      );
      updateLevels();
      return pill;
    }

    function calibrationView() {
      const c = state.calibration;
      const card = el('div', 'card');
      card.append(header(hide));

      if (c.phase === 'done' || c.phase === 'error') {
        if (c.phase === 'done') {
          const sep = Math.round(c.separationDb);
          const [text, cls] =
            sep > 15 ? ['excellent', 'ok'] : sep > 8 ? ['good', 'ok'] : ['low — move the mic closer', 'warn'];
          card.append(
            el('p', `big ${cls}`, 'Calibrated'),
            el('p', 'sub', `${sep} dB between your voice and the background (${text}). Saved for this microphone.`)
          );
        } else {
          card.append(el('p', 'big err', 'Calibration failed'), el('p', 'sub', c.message));
        }
        return card;
      }

      const voice = c.phase === 'voice';
      card.append(
        el('div', 'step', voice ? 'Step 2 of 2' : 'Step 1 of 2'),
        el('p', 'big', voice ? 'Now speak normally' : 'Stay quiet'),
        el(
          'p',
          'sub',
          voice
            ? 'Read any sentence aloud at your usual volume.'
            : 'Measuring the background noise around you.'
        )
      );
      const bar = el('div', voice ? 'bar voice' : 'bar');
      const fill = el('div');
      bar.append(fill);
      card.append(bar);
      if (c.durationMs) {
        const remaining = Math.max(0, c.durationMs - (Date.now() - c.startedAt));
        requestAnimationFrame(() => {
          fill.style.transition = `width ${remaining}ms linear`;
          fill.style.width = '100%';
        });
      }
      return card;
    }

    function errorView() {
      const card = el('div', 'card');
      card.append(
        header(() => {
          state.error = null;
          render();
        }),
        el('p', 'title', 'Noise cancellation unavailable'),
        el('p', 'sub', 'Noiseless could not process this microphone, so the call is using your normal mic.')
      );
      return card;
    }

    function render() {
      let view = null;
      if (state.error && !state.uiHidden) view = errorView();
      else if (state.detected && state.calibration && !state.uiHidden) view = calibrationView();
      else if (state.detected && !state.decided && !state.uiHidden) view = promptView();
      else if (state.detected && !state.uiHidden) view = pillView();

      if (!view) {
        if (hostEl) hostEl.remove();
        dot = stateText = null;
        return;
      }
      ensure();
      if (!view.contains(dot)) dot = stateText = null;
      panel.replaceChildren(view);
    }

    function updateLevels() {
      if (!dot) return;
      const voice = !!(state.levels && state.levels.voice);
      dot.className = `dot ${state.active ? (voice ? 'voice' : 'idle') : ''}`;
      if (state.audioState === 'suspended') stateText.textContent = 'Click the page to activate';
      else stateText.textContent = state.active ? (voice ? 'On · speaking' : 'On · silent') : 'Off';
    }

    return { render, updateLevels };
  })();
})();
