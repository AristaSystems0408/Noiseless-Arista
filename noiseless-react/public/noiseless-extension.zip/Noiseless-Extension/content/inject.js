/*
 * Noiseless — page hook (runs in the page's MAIN world at document_start).
 *
 * Wraps navigator.mediaDevices.getUserMedia. When a meeting asks for the microphone,
 * the mic is routed through the Noiseless AudioWorklet and the meeting receives the
 * processed track. The worklet starts in bypass, so audio is untouched until the user
 * clicks Start; Start/Stop then just flips the worklet without renegotiating the call.
 *
 * Talks to content.js (isolated world) with window.postMessage.
 */
(() => {
  if (window.__noiselessHooked) return;
  window.__noiselessHooked = true;

  const TAG = '__noiseless';
  const proto = window.MediaDevices && MediaDevices.prototype;
  if (!proto || !proto.getUserMedia) return;

  const origGetUserMedia = proto.getUserMedia;
  const origStop = MediaStreamTrack.prototype.stop;
  const origClone = MediaStreamTrack.prototype.clone;

  const state = {
    config: null,
    active: false,
    strength: 85,
    pipelines: new Set(),
    latest: null,
  };

  let resolveConfig;
  const configReady = new Promise((r) => (resolveConfig = r));

  const send = (msg) => window.postMessage({ [TAG]: 'page', ...msg }, '*');

  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data[TAG] !== 'content') return;
    const msg = e.data;
    switch (msg.type) {
      case 'config':
        state.config = msg;
        if (msg.strength != null) setStrength(msg.strength);
        resolveConfig(msg);
        break;
      case 'set-active':
        state.active = !!msg.active;
        for (const p of state.pipelines) {
          p.node.port.postMessage({ type: 'active', value: state.active });
          if (state.active) p.ctx.resume().catch(() => {});
        }
        break;
      case 'set-strength':
        setStrength(msg.strength);
        break;
      case 'calibrate':
        if (state.latest) state.latest.node.port.postMessage({ type: 'calibrate' });
        else send({ type: 'calibration', phase: 'error', message: 'No microphone is in use yet.' });
        break;
    }
  });

  function setStrength(pct) {
    state.strength = pct;
    for (const p of state.pipelines) p.node.port.postMessage({ type: 'strength', value: pct });
  }

  // Like the desktop app, the engine needs the raw mic. Browser auto-gain turns the background up
  // whenever you stop talking, which defeats the proximity gate; browser noise suppression is
  // redundant with ours. Echo cancellation is left as the meeting asked.
  const RAW = { autoGainControl: false, noiseSuppression: false };
  const asked = (v) => !(v === false || (v && typeof v === 'object' && (v.exact === false || v.ideal === false)));

  proto.getUserMedia = async function getUserMedia(constraints) {
    if (!constraints || !constraints.audio) return origGetUserMedia.call(this, constraints);
    const audio = constraints.audio === true ? {} : constraints.audio;
    let stream;
    try {
      const advanced = Array.isArray(audio.advanced) ? audio.advanced.map((c) => ({ ...c, ...RAW })) : undefined;
      const raw = advanced ? { ...audio, ...RAW, advanced } : { ...audio, ...RAW };
      stream = await origGetUserMedia.call(this, { ...constraints, audio: raw });
    } catch (err) {
      if (!err || (err.name !== 'OverconstrainedError' && err.name !== 'TypeError')) throw err;
      stream = await origGetUserMedia.call(this, constraints);
    }
    if (!stream.getAudioTracks().length) return stream;
    const reported = { autoGainControl: asked(audio.autoGainControl), noiseSuppression: asked(audio.noiseSuppression) };
    try {
      return await wrapStream(stream, reported);
    } catch (err) {
      console.warn('[Noiseless] Using the unprocessed microphone:', err);
      send({ type: 'error', message: String((err && err.message) || err) });
      return stream;
    }
  };

  // RNNoise engine first; the classic engine if the page cannot run WebAssembly
  async function createEngine(ctx, base, options) {
    try {
      await ctx.audioWorklet.addModule(`${base}rnnoise-processor.js`);
      return new AudioWorkletNode(ctx, 'noiseless-rnnoise', options);
    } catch (err) {
      console.warn('[Noiseless] RNNoise engine unavailable, using the classic engine:', err);
      await ctx.audioWorklet.addModule(`${base}classic-processor.js`);
      return new AudioWorkletNode(ctx, 'noiseless-classic', options);
    }
  }

  async function wrapStream(stream, reported) {
    const config = await Promise.race([
      configReady,
      new Promise((r) => setTimeout(() => r(null), 2000)),
    ]);
    if (!config) throw new Error('Noiseless extension did not respond');

    const rawTrack = stream.getAudioTracks()[0];
    const ctx = new AudioContext({ sampleRate: 48000, latencyHint: 'interactive' });
    let node, source;
    try {
      node = await createEngine(ctx, config.workletBase, {
        numberOfInputs: 1,
        numberOfOutputs: 1,
        outputChannelCount: [1],
        processorOptions: {
          active: state.active,
          strength: state.strength,
          profile: (config.profiles || {})[rawTrack.label] || null,
        },
      });
      source = ctx.createMediaStreamSource(new MediaStream([rawTrack]));
    } catch (err) {
      ctx.close().catch(() => {});
      throw err;
    }
    const dest = ctx.createMediaStreamDestination();
    dest.channelCount = 1;
    source.connect(node);
    node.connect(dest);

    const pipeline = {
      ctx,
      node,
      source,
      rawTrack,
      reported,
      label: rawTrack.label,
      engine: null,
      tracks: new Set(),
      closed: false,
    };
    node.port.onmessage = (e) => onWorkletMessage(pipeline, e.data);
    ctx.addEventListener('statechange', () => {
      if (pipeline === state.latest && !pipeline.closed) send({ type: 'audio-state', state: ctx.state });
    });

    const outTrack = dest.stream.getAudioTracks()[0];
    adoptTrack(pipeline, outTrack);

    // Mic unplugged / revoked: end the processed tracks too so the meeting notices
    rawTrack.addEventListener('ended', () => {
      for (const t of [...pipeline.tracks]) {
        origStop.call(t);
        t.dispatchEvent(new Event('ended'));
      }
      closePipeline(pipeline);
    });

    keepRunning(ctx);

    state.pipelines.add(pipeline);
    state.latest = pipeline;
    if (state.pipelines.size === 1) send({ type: 'capture-started', label: pipeline.label });
    else send({ type: 'capture-changed', label: pipeline.label });
    send({ type: 'audio-state', state: ctx.state });

    return new MediaStream([outTrack, ...stream.getVideoTracks()]);
  }

  // Make the processed track look and behave like the real mic track
  function adoptTrack(p, track) {
    p.tracks.add(track);
    const raw = p.rawTrack;
    Object.defineProperty(track, 'label', { get: () => raw.label, configurable: true });
    // Report the processing the meeting asked for, so it doesn't try to "fix" the raw capture
    track.getSettings = () => ({ ...raw.getSettings(), ...p.reported });
    track.getCapabilities = () => (raw.getCapabilities ? raw.getCapabilities() : {});
    track.getConstraints = () => raw.getConstraints();
    track.applyConstraints = (c) => raw.applyConstraints(c && typeof c === 'object' ? { ...c, ...RAW } : c);
    track.clone = function clone() {
      const copy = origClone.call(this);
      adoptTrack(p, copy);
      return copy;
    };
    track.stop = function stop() {
      origStop.call(this);
      p.tracks.delete(this);
      if (!p.tracks.size) closePipeline(p);
    };
  }

  function closePipeline(p) {
    if (p.closed) return;
    p.closed = true;
    try {
      p.node.port.postMessage({ type: 'dispose' });
      p.source.disconnect();
    } catch (_) {}
    p.ctx.close().catch(() => {});
    origStop.call(p.rawTrack);

    state.pipelines.delete(p);
    if (state.latest === p) {
      state.latest = [...state.pipelines].pop() || null;
      if (state.latest) send({ type: 'engine', engine: state.latest.engine });
    }
    if (!state.pipelines.size) send({ type: 'capture-ended' });
  }

  // Autoplay policy may leave the context suspended until the user interacts with the page
  function keepRunning(ctx) {
    const resume = () => ctx.state === 'suspended' && ctx.resume().catch(() => {});
    const events = ['pointerdown', 'keydown'];
    const cleanup = () => {
      if (ctx.state === 'suspended') return;
      events.forEach((ev) => window.removeEventListener(ev, resume, true));
    };
    events.forEach((ev) => window.addEventListener(ev, resume, true));
    ctx.addEventListener('statechange', cleanup);
    resume();
  }

  function onWorkletMessage(p, msg) {
    if (!msg) return;
    if (msg.type === 'engine') {
      p.engine = msg.engine;
      if (p === state.latest) send({ type: 'engine', engine: msg.engine });
    } else if (msg.type === 'levels') {
      if (p === state.latest) send({ type: 'levels', inRms: msg.inRms, outRms: msg.outRms, voice: msg.voice });
    } else if (msg.type === 'calibration') {
      if (msg.phase === 'done') {
        for (const other of state.pipelines) {
          if (other !== p && other.label === p.label) {
            other.node.port.postMessage({ type: 'profile', profile: msg.profile });
          }
        }
      }
      send({ ...msg, label: p.label });
    }
  }

  send({ type: 'hello' });
})();
