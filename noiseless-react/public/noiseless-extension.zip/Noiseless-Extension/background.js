/*
 * Noiseless — service worker. Shows the per-tab ON/OFF badge for detected meetings.
 */

chrome.runtime.onInstalled.addListener(async ({ previousVersion }) => {
  const current = await chrome.storage.sync.get(['strength', 'autoStartSites']);
  // v4.0 defaulted to 85%; v4.1 defaults to 95% (the strict "Maximum" gate)
  const keptOldDefault = previousVersion && previousVersion.startsWith('4.0') && current.strength === 85;
  await chrome.storage.sync.set({
    strength: current.strength == null || keptOldDefault ? 95 : current.strength,
    autoStartSites: current.autoStartSites ?? {},
  });
});

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!msg || msg.type !== 'tab-state' || !sender.tab) return;
  const tabId = sender.tab.id;

  if (!msg.detected) {
    chrome.action.setBadgeText({ tabId, text: '' });
    chrome.action.setTitle({ tabId, title: 'Noiseless' });
    return;
  }
  chrome.action.setBadgeText({ tabId, text: msg.active ? 'ON' : 'OFF' });
  chrome.action.setBadgeBackgroundColor({ tabId, color: msg.active ? '#00A888' : '#566070' });
  chrome.action.setBadgeTextColor({ tabId, color: '#FFFFFF' });
  chrome.action.setTitle({
    tabId,
    title: msg.active
      ? 'Noiseless — noise cancellation is ON'
      : 'Noiseless — meeting detected, noise cancellation is OFF',
  });
});

chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.status === 'loading') chrome.action.setBadgeText({ tabId, text: '' });
});
