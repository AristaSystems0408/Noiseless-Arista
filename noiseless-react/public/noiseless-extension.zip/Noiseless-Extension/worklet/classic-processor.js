/*
 * Noiseless — classic engine (AudioWorklet). Used only when the RNNoise engine cannot load,
 * e.g. on a page whose security policy blocks WebAssembly.
 *
 * Port of the v3.1 desktop engine (files/NoiseSuppressor.pyw): proximity VAD gate,
 * 70 Hz high-pass, overlap-add spectral gating with voice-band protection, soft limiter.
 */
import { Calibration, HighPass, ProximityVAD, limit, percentile, rms, toDb } from './engine-common.js';

const FFT_SIZE = 2048;
const HOP = 512;
const BINS = FFT_SIZE / 2 + 1;
const VOICE_LOW = 250;
const VOICE_HIGH = 3800;
const FIFO_SIZE = 4096; // power of two, > FFT_SIZE
const LEVEL_EVERY = 20; // render quanta between level reports (~53 ms)

// Symmetric Hann window, same as numpy.hanning
function hann(n) {
  const w = new Float32Array(n);
  for (let i = 0; i < n; i++) w[i] = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (n - 1));
  return w;
}

// In-place iterative radix-2 complex FFT. Inverse divides by n (like numpy).
function makeFFT(n) {
  const levels = Math.log2(n);
  const rev = new Uint32Array(n);
  for (let i = 0; i < n; i++) {
    let r = 0;
    for (let b = 0; b < levels; b++) r |= ((i >> b) & 1) << (levels - 1 - b);
    rev[i] = r;
  }
  const cos = new Float64Array(n / 2);
  const sin = new Float64Array(n / 2);
  for (let i = 0; i < n / 2; i++) {
    cos[i] = Math.cos((2 * Math.PI * i) / n);
    sin[i] = Math.sin((2 * Math.PI * i) / n);
  }
  return function fft(re, im, inverse) {
    for (let i = 0; i < n; i++) {
      const j = rev[i];
      if (j > i) {
        let t = re[i]; re[i] = re[j]; re[j] = t;
        t = im[i]; im[i] = im[j]; im[j] = t;
      }
    }
    for (let size = 2; size <= n; size <<= 1) {
      const half = size >> 1;
      const step = n / size;
      for (let i = 0; i < n; i += size) {
        for (let j = i, k = 0; j < i + half; j++, k += step) {
          const wr = cos[k];
          const wi = inverse ? sin[k] : -sin[k];
          const l = j + half;
          const tr = re[l] * wr - im[l] * wi;
          const ti = re[l] * wi + im[l] * wr;
          re[l] = re[j] - tr;
          im[l] = im[j] - ti;
          re[j] += tr;
          im[j] += ti;
        }
      }
    }
    if (inverse) {
      for (let i = 0; i < n; i++) {
        re[i] /= n;
        im[i] /= n;
      }
    }
  };
}

class ClassicProcessor extends AudioWorkletProcessor {
  constructor(options) {
    super();
    const opts = (options && options.processorOptions) || {};

    this.active = !!opts.active;
    this.vad = new ProximityVAD(sampleRate);
    this.strength = 1.0;
    this.setStrengthPct(opts.strength == null ? 85 : opts.strength);

    this.fft = makeFFT(FFT_SIZE);
    this.window = hann(FFT_SIZE);
    let energy = 0;
    for (let i = 0; i < FFT_SIZE; i++) energy += this.window[i] * this.window[i];
    this.olaNorm = energy / HOP;

    this.inBuf = new Float32Array(FFT_SIZE);
    this.ola = new Float32Array(FFT_SIZE);
    this.re = new Float64Array(FFT_SIZE);
    this.im = new Float64Array(FFT_SIZE);
    this.mag = new Float32Array(BINS);
    this.gain = new Float32Array(BINS);
    this.prevGain = null;
    this.noiseEst = null;
    this.noiseFloor = null;

    this.voiceProtection = new Float32Array(BINS);
    for (let i = 0; i < BINS; i++) {
      const f = (i * sampleRate) / FFT_SIZE;
      if (f >= VOICE_LOW && f <= VOICE_HIGH) this.voiceProtection[i] = 1;
      else if (f < VOICE_LOW) this.voiceProtection[i] = Math.max(0.15, f / VOICE_LOW);
      else this.voiceProtection[i] = Math.max(0.05, Math.max(0, 1 - (f - VOICE_HIGH) / 3000));
    }

    this.hp = new HighPass(70, sampleRate);
    this.hopRaw = new Float32Array(HOP);
    this.hopFilt = new Float32Array(HOP);
    this.hopFill = 0;
    this.prevGate = 0;

    this.fifo = new Float32Array(FIFO_SIZE);
    this.fifoRead = 0;
    this.fifoWrite = 0;
    this.fifoCount = 0;

    this.mono = new Float32Array(128);
    this.peakIn = 0;
    this.peakOut = 0;
    this.quanta = 0;

    this.calibration = null;
    this.disposed = false;

    if (opts.profile) this.applyProfile(opts.profile);
    this.port.onmessage = (e) => this.onMessage(e.data || {});
    this.port.postMessage({ type: 'engine', engine: 'classic' });
  }

  onMessage(msg) {
    switch (msg.type) {
      case 'active':
        this.active = !!msg.value;
        break;
      case 'strength':
        this.setStrengthPct(msg.value);
        break;
      case 'profile':
        this.applyProfile(msg.profile);
        break;
      case 'calibrate':
        this.calibration = new Calibration(sampleRate, this.port, (noise) => this.noiseSpectrum(noise));
        break;
      case 'dispose':
        this.disposed = true;
        break;
    }
  }

  setStrengthPct(pct) {
    this.strength = Math.min(2, Math.max(0, Number(pct) / 50));
    this.vad.setStrength(this.strength);
  }

  applyProfile(p) {
    if (!p || !(p.noiseRms > 0) || !(p.voiceRms > 0)) return;
    if (p.noiseFloor && p.noiseFloor.length === BINS) this.noiseFloor = Float32Array.from(p.noiseFloor);
    this.vad.applyLevels(p.noiseRms, p.voiceRms);
  }

  // ── Real-time path ──────────────────────────────────────────────
  process(inputs, outputs) {
    if (this.disposed) return false;
    const out = outputs[0] && outputs[0][0];
    if (!out) return true;
    const input = inputs[0];
    if (!input || !input.length) {
      out.fill(0);
      return true;
    }

    const n = out.length;
    if (this.mono.length !== n) this.mono = new Float32Array(n);
    const c0 = input[0];
    const c1 = input[1];
    let inSq = 0;
    for (let i = 0; i < n; i++) {
      const x = c1 ? 0.5 * (c0[i] + c1[i]) : c0[i];
      this.mono[i] = x;
      inSq += x * x;
      this.hopRaw[this.hopFill++] = x;
      if (this.hopFill === HOP) {
        this.processHop();
        this.hopFill = 0;
      }
    }

    let outSq = 0;
    for (let i = 0; i < n; i++) {
      let y = 0;
      if (this.fifoCount > 0) {
        y = this.fifo[this.fifoRead];
        this.fifoRead = (this.fifoRead + 1) & (FIFO_SIZE - 1);
        this.fifoCount--;
      }
      const v = this.active ? y : this.mono[i];
      out[i] = v;
      outSq += v * v;
    }

    if (this.calibration) this.feedCalibration(this.mono);

    this.peakIn = Math.max(this.peakIn, Math.sqrt(inSq / n));
    this.peakOut = Math.max(this.peakOut, Math.sqrt(outSq / n));
    if (++this.quanta >= LEVEL_EVERY) {
      this.port.postMessage({
        type: 'levels',
        inRms: this.peakIn,
        outRms: this.peakOut,
        voice: this.vad.speechActive,
      });
      this.quanta = 0;
      this.peakIn = 0;
      this.peakOut = 0;
    }
    return true;
  }

  processHop() {
    const raw = this.hopRaw;
    const gate = this.vad.detect(rms(raw));

    const f = this.hopFilt;
    for (let i = 0; i < HOP; i++) f[i] = this.hp.process(raw[i]);

    this.inBuf.copyWithin(0, HOP);
    this.inBuf.set(f, FFT_SIZE - HOP);

    const { re, im, window: win } = this;
    for (let i = 0; i < FFT_SIZE; i++) {
      re[i] = this.inBuf[i] * win[i];
      im[i] = 0;
    }
    this.fft(re, im, false);
    for (let k = 0; k < BINS; k++) this.mag[k] = Math.hypot(re[k], im[k]);

    const g = this.computeGain(this.mag, rms(f), gate);
    for (let k = 0; k < BINS; k++) {
      re[k] *= g[k];
      im[k] *= g[k];
      if (k > 0 && k < BINS - 1) {
        re[FFT_SIZE - k] *= g[k];
        im[FFT_SIZE - k] *= g[k];
      }
    }
    this.fft(re, im, true);

    const ola = this.ola;
    for (let i = 0; i < FFT_SIZE; i++) ola[i] += (re[i] * win[i]) / this.olaNorm;

    // Emit one hop: gate (ramped to avoid clicks) + soft limiter
    const g0 = this.prevGate;
    for (let i = 0; i < HOP; i++) {
      const gg = g0 + ((gate - g0) * (i + 1)) / HOP;
      this.fifo[this.fifoWrite] = gg < 0.01 ? 0 : limit(ola[i] * Math.min(1, gg));
      this.fifoWrite = (this.fifoWrite + 1) & (FIFO_SIZE - 1);
    }
    this.fifoCount = Math.min(FIFO_SIZE, this.fifoCount + HOP);
    this.prevGate = gate;

    ola.copyWithin(0, HOP);
    ola.fill(0, FFT_SIZE - HOP);
  }

  computeGain(mag, hopRms, gate) {
    const s = this.strength;
    const gain = this.gain;
    let noise;
    let scale;
    if (this.noiseFloor) {
      noise = this.noiseFloor;
      scale = 1.5 + s * 1.5; // 1.5x .. 4.5x over-subtraction
    } else {
      if (!this.noiseEst) {
        if (hopRms > 1e-6) this.noiseEst = Float32Array.from(mag);
      } else if (hopRms < this.vad.speechThreshold) {
        for (let k = 0; k < BINS; k++) this.noiseEst[k] = 0.988 * this.noiseEst[k] + 0.012 * mag[k];
      }
      noise = this.noiseEst;
      scale = 1 + s;
    }

    const beta = 1.5 + s * 5.0;
    const prot = Math.max(0.03, 0.1 - s * 0.03);
    const minG = gate > 0.5 ? 0.03 : 0;
    const prev = this.prevGain;

    for (let k = 0; k < BINS; k++) {
      let g = 1;
      if (noise) {
        const snr = mag[k] / (noise[k] * scale + 1e-10);
        const snr2 = snr * snr;
        g = Math.min(1, Math.max(0, (snr2 - 1) / (snr2 + beta)));
      }
      if (gate > 0.5) g = Math.min(1, g + this.voiceProtection[k] * prot * (1 - g));
      g = Math.max(g, minG);
      if (prev) g = g > prev[k] ? 0.45 * prev[k] + 0.55 * g : 0.8 * prev[k] + 0.2 * g;
      gain[k] = g;
    }
    if (!this.prevGain) this.prevGain = new Float32Array(BINS);
    this.prevGain.set(gain);
    return gain;
  }

  // 80th-percentile magnitude per bin over half-overlapping Hann frames
  noiseSpectrum(noise) {
    const re = new Float64Array(FFT_SIZE);
    const im = new Float64Array(FFT_SIZE);
    const frames = [];
    for (let i = 0; i + FFT_SIZE < noise.length; i += FFT_SIZE / 2) {
      for (let j = 0; j < FFT_SIZE; j++) {
        re[j] = noise[i + j] * this.window[j];
        im[j] = 0;
      }
      this.fft(re, im, false);
      const m = new Float32Array(BINS);
      for (let k = 0; k < BINS; k++) m[k] = Math.hypot(re[k], im[k]);
      frames.push(m);
    }
    const floor = new Float32Array(BINS);
    const column = new Float64Array(frames.length);
    for (let k = 0; k < BINS; k++) {
      for (let f = 0; f < frames.length; f++) column[f] = frames[f][k];
      floor[k] = percentile(column, 80);
    }
    return floor;
  }

  feedCalibration(samples) {
    const result = this.calibration.feed(samples);
    if (!result) return;
    this.calibration = null;
    if (!Calibration.evaluate(sampleRate, result.noise, result.voice)) {
      Calibration.fail(this.port);
      return;
    }
    this.noiseFloor = result.extra;
    this.vad.calibrateNoise(result.noise);
    this.vad.calibrateVoice(result.voice);
    this.port.postMessage({
      type: 'calibration',
      phase: 'done',
      profile: {
        engine: 'classic',
        noiseFloor: Array.from(result.extra),
        noiseRms: this.vad.noiseRms,
        voiceRms: this.vad.voiceRms,
        separationDb: toDb(this.vad.voiceRms) - toDb(this.vad.noiseRms),
        createdAt: Date.now(),
      },
    });
  }
}

registerProcessor('noiseless-classic', ClassicProcessor);
