# Noiseless — Chrome Extension (v4.2)
### Arista Systems Pvt Ltd · AI Automation Team

Removes background noise from your microphone in **browser** meetings. Noiseless notices when a meeting starts and asks whether to turn noise cancellation on.

Supported: Google Meet, Microsoft Teams (web), Zoom (web client), Webex (web), in Chrome or Edge.
Unlike the desktop app, it needs **no Python, no VB-CABLE, and no change to the meeting's mic setting**.

## Install (testing / small teams)

1. Open `chrome://extensions` (or `edge://extensions`).
2. Turn on **Developer mode** (top right).
3. Click **Load unpacked** and select this `extension` folder.
4. Pin the Noiseless icon to the toolbar.

## Using it

1. Join a meeting, or open its pre-join screen. When the page starts using your mic, a card appears:
   **"Meeting detected — turn on noise cancellation?"** → **Start** or **Not now**.
   Tick *Always start automatically* to skip the question on that site in future.
2. A small control stays at the bottom-left of the page: **● Noise cancellation · On · speaking  [Stop]**.
   Start or stop it at any time during the call. The call is not interrupted.
3. The toolbar icon shows **ON / OFF** for the meeting tab. Its popup has:
   - Start / Stop
   - Strength slider. The default is 95%. At 90–100% only speech close to your own level gets through, which is best in busy offices. Lower it if soft words get cut. The levels match the desktop app's slider.
   - Live mic and "sent" levels, and how much background is being removed
   - Which engine is running, and a warning if the browser has paused audio (click the meeting page to fix)
   - **Calibrate (8 sec)**, optional: stay quiet for 3 sec, then speak for 4 sec. Saved per microphone.
   - Auto-start for this site

Without calibration, Noiseless runs in **auto mode**. It spends the first half-second measuring the room, learns your voice level from your first few words, and keeps adapting as you talk. It works at any mic level. Auto mode reaches calibrated quality after the first 5–10 seconds of a call; calibrate once if you want full quality from the first word.

## How it works

```
Meeting page asks for the mic (getUserMedia)
   └─ content/inject.js requests the RAW mic (browser auto-gain and noise suppression off,
      echo cancellation unchanged) and hands the meeting a processed track:

   mic ─► 70 Hz high-pass ─► RNNoise (neural denoiser) ─► 30 ms look-ahead ─► gate ─► limiter ─► meeting
                                  │ speech probability                         ▲
                                  └──────► proximity VAD (from the desktop app) ┘
```

- **RNNoise** removes non-speech noise: fans, AC, typing, traffic, clatter.
- The **proximity gate** (your desktop engine's VAD) opens only for sound that RNNoise says is speech *and* that is loud enough to be the person at the mic. Otherwise the output is true digital silence. Nearby colleagues' voices are blocked while you're not talking.
- **Raw mic:** the browser's auto-gain raises the background whenever you stop talking, which defeats any level-based gate. The desktop app always used the raw mic, so the extension does too.
- If a site blocks WebAssembly, the **classic engine** is used instead: your original spectral-gating algorithm with the same gate. The popup shows which engine is active.

The engine starts in bypass, so audio is untouched until you press Start. Start/Stop just flips it. Latency when on is about 60 ms.
Note that when it is off, the meeting gets the raw mic without the browser's own auto-gain.

### Measured quality (v4.2, against the desktop app)

Same office recording (`../test-samples/1_before_office_noise.wav`) at three mic levels and in a noisier room, at 95%. The desktop app is calibrated, as it requires; the extension runs in auto mode, measured after the first pass through the recording. "Silent" = share of background-only moments that come out as true silence; "cut" = share of your speech that is lost.

| Scenario | Desktop app: silent / cut | Extension v4.1: silent / cut | **Extension v4.2: silent / cut** |
|---|---|---|---|
| Recording as is (voice −22 dBFS) | 79% / 2% | 72% / 0% | **79% / 4%** |
| Typical raw mic (voice −37 dBFS) | 82% / 2% | 98% / **89% (you are muted)** | **81% / 4%** |
| Soft or distant (voice −47 dBFS) | 88% / 2% | 100% / **100% (you are muted)** | **83% / 4%** |
| Noisy office (background +8 dB) | 84% / 34% | 68% / 0% | **80% / 11–13%** |

v4.1's auto mode assumed a −26 dBFS voice. With the browser's auto-gain off, most real mics are far quieter, so it learned your voice as background and stayed muted. v4.2 learns your level from what RNNoise says is speech, at any mic gain, and uses the desktop app's gate settings (threshold, 30 ms hold, release) so the gaps between your words close as fast as on the desktop.

Pauses longer than half a second are silent in both. The remaining difference is the 0.1–0.25 s just after you stop talking.

Listen for yourself in `../test-samples/` (before vs. after, recorded from the extension running in the browser).

| File | Purpose |
|------|---------|
| `manifest.json` | Extension definition (Manifest V3) |
| `content/inject.js` | Runs in the page; captures the raw mic and builds the audio pipeline |
| `content/content.js` | Meeting detection, in-page prompt and control, settings |
| `worklet/rnnoise-processor.js` | Main engine: RNNoise + proximity gate |
| `worklet/classic-processor.js` | Fallback engine: JS port of `files/NoiseSuppressor.pyw` |
| `worklet/engine-common.js` | Shared VAD, high-pass, limiter, calibration |
| `worklet/vendor/rnnoise-sync.js` | RNNoise compiled to WebAssembly ([@jitsi/rnnoise-wasm](https://github.com/jitsi/rnnoise-wasm) 0.2.1, Apache-2.0; RNNoise by Xiph.Org/Mozilla, BSD-3-Clause) |
| `popup/` | Toolbar popup |
| `background.js` | Per-tab ON/OFF badge |

## Rolling out to the company

- **Chrome Web Store (unlisted or private to the Google Workspace domain):** zip this folder and upload it. Updates then reach everyone automatically.
- **Forced install:** once it is in the store, push it with the *ExtensionInstallForcelist* policy (Google Admin console, or Group Policy / Intune for Chrome and Edge). No user action is needed.

## Limitations

- Works only for meetings **in the browser**. The desktop Zoom/Teams apps still need the desktop Noiseless app.
- Your voice can't be separated from a colleague's voice *while you are both talking at once*. The gate removes them whenever you're quiet.
- The meeting app's own noise cancellation (e.g. in Meet) can stay on; the two stack without problems.
- After updating the extension, refresh any open meeting tabs.
- To support another meeting site, add its URL to the three `matches` lists in `manifest.json`.
