const $ = (id) => document.getElementById(id);

let tabId = null;
let current = null;
let peakIn = 0;
let peakOut = 0;
let suppressionDb = 0;
let strengthTimer = null;

const ask = (msg) => chrome.tabs.sendMessage(tabId, msg).catch(() => null);

function levelPct(r) {
  if (!r || r <= 1e-7) return 0;
  const norm = Math.max(0, Math.min(1, (20 * Math.log10(r) + 60) / 50));
  return Math.round(norm ** 0.6 * 100);
}

function render(s) {
  current = s;
  const chip = $('chip');

  if (!s) {
    chip.textContent = 'IDLE';
    chip.className = 'chip';
    $('siteTitle').textContent = 'No meeting in this tab';
    $('siteSub').textContent =
      'Noiseless works with Google Meet, Microsoft Teams, Zoom and Webex in Chrome. Join a call there and it will offer to start.';
    $('controls').hidden = true;
    return;
  }

  $('controls').hidden = false;
  $('autoStartSite').textContent = s.platform;
  $('autoStart').checked = s.autoStart;

  if (!s.detected) {
    chip.textContent = 'WAITING';
    chip.className = 'chip';
    $('siteTitle').textContent = `${s.platform} — no call yet`;
    $('siteSub').textContent = 'Join a call (or open the pre-join screen) and Noiseless will ask whether to start.';
  } else {
    chip.textContent = s.active ? 'ON' : 'OFF';
    chip.className = s.active ? 'chip on' : 'chip';
    $('siteTitle').textContent = `Meeting detected on ${s.platform}`;
    $('siteSub').textContent = s.label ? `Microphone: ${s.label}` : '';
  }

  const toggle = $('toggle');
  toggle.disabled = !s.detected;
  toggle.className = `toggle ${s.active && s.detected ? 'stop' : 'start'}`;
  toggle.textContent = s.active && s.detected ? 'Stop noise cancellation' : 'Start noise cancellation';

  $('liveCard').hidden = !s.detected;
  $('engine').textContent =
    s.engine === 'rnnoise'
      ? 'Engine: AI denoiser (RNNoise) + proximity gate · raw mic'
      : s.engine === 'classic'
        ? 'Engine: classic spectral (this site blocks the AI engine) · raw mic'
        : '';
  const warning = $('warning');
  warning.hidden = s.audioState !== 'suspended';
  warning.textContent = 'Audio is paused by the browser. Click anywhere on the meeting page to activate it.';
  renderLevels(s);
  renderCalibration(s);
  $('showControls').hidden = !(s.detected && s.uiHidden);
}

function renderLevels(s) {
  const l = s.levels;
  const inRms = l ? l.inRms : 0;
  const outRms = l ? l.outRms : 0;
  peakIn = Math.max(inRms, peakIn * 0.85);
  peakOut = Math.max(outRms, peakOut * 0.85);
  $('inBar').style.width = `${levelPct(peakIn)}%`;
  $('outBar').style.width = `${levelPct(peakOut)}%`;

  const gate = $('gate');
  if (!s.active) {
    gate.textContent = 'Bypassed';
    gate.className = 'gate';
  } else if (l && l.voice) {
    gate.textContent = '● Voice detected';
    gate.className = 'gate voice';
  } else {
    gate.textContent = '● Silent (gated)';
    gate.className = 'gate silent';
  }

  const ratio = peakIn > 1e-7 ? Math.max(peakOut / peakIn, 1e-6) : 1;
  const target = s.active ? Math.min(60, Math.max(0, -20 * Math.log10(ratio))) : 0;
  suppressionDb = 0.7 * suppressionDb + 0.3 * target;
  $('suppression').textContent = `−${Math.round(suppressionDb)} dB`;
}

function renderCalibration(s) {
  const status = $('calStatus');
  const progress = $('calProgress');
  const fill = $('calFill');
  const button = $('calibrate');
  const c = s.calibration;
  const running = c && ['starting', 'noise', 'voice'].includes(c.phase);

  button.disabled = !s.detected || running;
  progress.hidden = !running;
  status.replaceChildren();

  if (running) {
    const voice = c.phase === 'voice';
    progress.className = voice ? 'cal-progress voice' : 'cal-progress';
    const pct = c.durationMs ? Math.min(100, ((Date.now() - c.startedAt) / c.durationMs) * 100) : 0;
    fill.style.width = `${pct}%`;
    const b = document.createElement('b');
    b.textContent = voice ? 'Step 2 · Now speak normally' : 'Step 1 · Stay quiet';
    status.append(b, document.createTextNode(voice ? ' — read any sentence aloud.' : ' — measuring background noise.'));
    return;
  }

  if (c && c.phase === 'error') {
    const span = document.createElement('span');
    span.className = 'err';
    span.textContent = c.message || 'Calibration failed.';
    status.append(span);
    return;
  }

  if (s.profile) {
    const sep = Math.round(s.profile.separationDb);
    const [text, cls] = sep > 15 ? ['excellent', 'ok'] : sep > 8 ? ['good', 'ok'] : ['low — move the mic closer', 'warn'];
    const span = document.createElement('span');
    span.className = cls;
    span.textContent = `Calibrated · ${sep} dB separation (${text})`;
    status.append(span);
    button.textContent = 'Recalibrate (8 sec)';
  } else {
    status.textContent = s.detected
      ? 'Auto mode — adapts to your room on its own. Calibrating is optional; it helps if you speak softly. Saved per mic.'
      : 'Available once a call is using your microphone.';
    button.textContent = 'Calibrate (8 sec)';
  }
}

async function poll() {
  if (tabId == null) return;
  render(await ask({ type: 'get-state' }));
}

function setStrengthLabel(v) {
  $('strengthValue').textContent = `${v}%`;
}

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  tabId = tab ? tab.id : null;

  const { strength = 95 } = await chrome.storage.sync.get('strength');
  $('strength').value = strength;
  setStrengthLabel(strength);

  $('strength').addEventListener('input', (e) => {
    const v = Number(e.target.value);
    setStrengthLabel(v);
    clearTimeout(strengthTimer);
    strengthTimer = setTimeout(() => chrome.storage.sync.set({ strength: v }), 200);
  });

  $('toggle').addEventListener('click', async () => {
    if (!current || !current.detected) return;
    await ask({ type: 'set-active', active: !current.active });
    poll();
  });

  $('calibrate').addEventListener('click', async () => {
    await ask({ type: 'calibrate' });
    poll();
  });

  $('autoStart').addEventListener('change', async (e) => {
    if (!current) return;
    const { autoStartSites = {} } = await chrome.storage.sync.get('autoStartSites');
    if (e.target.checked) autoStartSites[current.host] = true;
    else delete autoStartSites[current.host];
    await chrome.storage.sync.set({ autoStartSites });
  });

  $('showControls').addEventListener('click', async () => {
    await ask({ type: 'show-controls' });
    poll();
  });

  await poll();
  setInterval(poll, 100);
}

init();
